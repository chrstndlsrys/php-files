<?php 
	$conn=mysqli_connect("localhost","root","","my_db") or die("Error in Connecting.");
?>