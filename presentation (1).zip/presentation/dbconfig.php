<?php
	$conn = new mysqli('localhost', 'root', '', 'my_db') 
		or die ('Cannot connect to database.');
?>